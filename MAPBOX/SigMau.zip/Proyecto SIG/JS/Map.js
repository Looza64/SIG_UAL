mapboxgl.accessToken = 'pk.eyJ1IjoiYXJjZXoiLCJhIjoiY2s2Mmx4M2t0MGZ3aDNscG1hY2t2cDdxNCJ9.sIWuKq1dXS4v_QB87b5CBQ';
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/dark-v10', //hosted style id
center: [-77.38, 39], // starting position
zoom: 3 // starting zoom
});
({
	container: 'map', // container id
	style: 'mapbox://styles/mapbox/streets-v11',
	center: [-74.5, 40], // starting position
	zoom: 9 // starting zoom
	});
	 
	// Add zoom and rotation controls to the map.
	map.addControl(new mapboxgl.NavigationControl());
	map.addControl(
		new mapboxgl.GeolocateControl({
		positionOptions: {
		enableHighAccuracy: true
		},
		trackUserLocation: true
		})
		);
		({
			container: 'map', // container id
			style: 'mapbox://styles/mapbox/streets-v11',
			center: [-74.5, 40], // starting position
			zoom: 9 // starting zoom
			});
			 
			map.on('mousemove', function(e) {
			document.getElementById('info').innerHTML =
			// e.point is the x, y coordinates of the mousemove event relative
			// to the top-left corner of the map
			JSON.stringify(e.point) +
			'<br />' +
			// e.lngLat is the longitude, latitude geographical position of the event
			JSON.stringify(e.lngLat.wrap());
			});
map.on('click', function(e) {
	document.getElementById('info').innerHTML =
	JSON.stringify(e.lngLat.wrap());
	var marker=new mapboxgl.Marker()
	.setLngLat(e.lngLat.wrap())
	.addTo(map);
	});
