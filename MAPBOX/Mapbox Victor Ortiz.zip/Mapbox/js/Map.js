mapboxgl.accessToken = 'pk.eyJ1IjoiYXJjZXoiLCJhIjoiY2s2Mmx4M2t0MGZ3aDNscG1hY2t2cDdxNCJ9.sIWuKq1dXS4v_QB87b5CBQ';
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/dark-v10', //hosted style id
center: [-77.38, 39], // starting position
zoom: 3 // starting zoom
}); 
// Add zoom and rotation controls to the map.
map.addControl(new mapboxgl.NavigationControl());
// Add geolocate control to the map.
map.addControl(
    new mapboxgl.GeolocateControl({
    positionOptions: {
    enableHighAccuracy: true
    },
    trackUserLocation: true
    })
    ); 
    map.on('mousemove', function(e) {
        document.getElementById('info').innerHTML =
        // e.point is the x, y coordinates of the mousemove event relative
        // to the top-left corner of the map
        JSON.stringify(e.point) +
        '<br />' +
        // e.lngLat is the longitude, latitude geographical position of the event
        JSON.stringify(e.lngLat.wrap());
        });
//Driving Directions
    map.addControl(
    new MapboxDirections({
    accessToken: mapboxgl.accessToken
    }),
    'top-left'
    );
//Marker
map.on('click', function(e) {
    document.getElementById('info').innerHTML = JSON.stringify(e.lngLat.wrap());

    var img=document.createElement('div');
    img.className="img";

    var marker = new mapboxgl.Marker()
    .setLngLat( e.lngLat.wrap())
    .addTo(map);
    });