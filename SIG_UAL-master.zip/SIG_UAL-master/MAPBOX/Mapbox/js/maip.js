mapboxgl.accessToken = 'pk.eyJ1Ijoic2hva29sYXQiLCJhIjoiY2s2Mmx4MWk3MDBjdTNwbnlrODNjOGwzayJ9.-QWso7fdPCt3Ap7X1Rbmig';
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/dark-v10', //hosted style id
center: [-77.38, 39], // starting position
zoom: 3 // starting zoom
});
map.addControl(
new mapboxgl.GeolocateControl({
positionOptions: {
enableHighAccuracy: true
},
trackUserLocation: true
})
);
map.addControl(new mapboxgl.NavigationControl());

map.on('mousemove', function(e) {
    document.getElementById('info').innerHTML =
    // e.point is the x, y coordinates of the mousemove event relative
    // to the top-left corner of the map
    JSON.stringify(e.point) +
    '<br />' +
    // e.lngLat is the longitude, latitude geographical position of the event
    JSON.stringify(e.lngLat.wrap());
    });

/*map.addControl(
    new MapboxDirections({
    accessToken: mapboxgl.accessToken
    }),
    'top-left'
    );*/

    map.on('click', function(e) {
        document.getElementById('info').innerHTML = JSON.stringify(e.lngLat.wrap());

        /*var img=document.createElement('div');
        img.className="img";*/

        var marker = new mapboxgl.Marker()
        .setLngLat( e.lngLat.wrap())
        .addTo(map);
        });