    mapboxgl.accessToken = 'pk.eyJ1IjoiZGVhdGhtYXA4MSIsImEiOiJjazYybHkwNWwwZnMzM2tyMHBpajYwbWJhIn0.9Uk9SJLeKb2EB90OMBGXVQ';
    var map = new mapboxgl.Map({
    container: 'map', // container id
    style: 'mapbox://styles/mapbox/streets-v11', // stylesheet location
    center: [-74.5, 40], // starting position [lng, lat]
    zoom: 9 // starting zoom
    });

    
    // Add zoom and rotation controls to the map.
    map.addControl(new mapboxgl.NavigationControl());

    map.addControl(
        new mapboxgl.GeolocateControl({
        positionOptions: {
        enableHighAccuracy: true
        },
        trackUserLocation: true
        })
        );

        map.on('mousemove', function(e) {
            document.getElementById('info').innerHTML =
            // e.point is the x, y coordinates of the mousemove event relative
            // to the top-left corner of the map
            JSON.stringify(e.point) +
            '<br />' +
            // e.lngLat is the longitude, latitude geographical position of the event
            JSON.stringify(e.lngLat.wrap() );
            });
  

    
map.on('click', function(e){
    document.getElementById('info').innerHTML =
    JSON.stringify( e.lngLat.wrap());

    var marker = new mapboxgl.Marker()
    .setLngLat( e.lngLat.wrap())
    .addTo(map);
    
    });

    map.addControl(
        new MapboxDirections({
        accessToken: mapboxgl.accessToken
        }),
        'top-left'
        );

fetch("https://raw.githubusercontent.com/GITDeath69/JSON-MAP/master/Json")
.then(datos=>datos.JSON())
.then(datos=>{console.log(datos)})

