mapboxgl.accessToken = 'pk.eyJ1Ijoia2ltYXQiLCJhIjoiY2s2OGM1dDZxMDNoeDNscWoweTdta2JmMSJ9.Cw5qz_56iFY9eonL0YQqNw';
var map = new mapboxgl.Map({
container: 'map', // container id
style: 'mapbox://styles/mapbox/streets-v11', // stylesheet location
center: [-74.5, 40], // starting position [lng, lat]
zoom: 9 // starting zoom
})

map.on('mousemove', function (e) {
    document.getElementById('coordenadas').innerHTML =
        JSON.stringify(e.lngLat);
});