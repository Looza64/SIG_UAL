
 var apik='?api_key=RGAPI-79038f8d-8be2-4dc6-8ebc-bf3393ee046f'
 var usuario = document.getElementById('usuario')
 var user
 var lev= document.getElementById('lev')
 var status = document.getElementById('stats')
 var so= document.getElementById('so')
 var ragion = document.getElementById('region')
 
// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyA6Wly0NT5qwNhrhVfeyP-EqCvWHFtvgZw",
    authDomain: "crybaby-bd423.firebaseapp.com",
    databaseURL: "https://crybaby-bd423.firebaseio.com",
    projectId: "crybaby-bd423",
    storageBucket: "crybaby-bd423.appspot.com",
    messagingSenderId: "208364862091",
    appId: "1:208364862091:web:4507c0e376b5a0f8e5f28e",
    measurementId: "G-428ZHHEGRR"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  var db = firebase.firestore();

var aplicacion={
  registro : function() {
 var correo = document.getElementById('email').value;
 var password = document.getElementById('pass').value;

 firebase.auth().createUserWithEmailAndPassword(correo, password)
 .catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // ...
  console.log(errorMessage)
})
},
 conect : function(){
  var correo = document.getElementById('email').value;
  var password = document.getElementById('pass').value;
firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // [START_EXCLUDE]
  if (errorCode === 'auth/wrong-password') {
    alert('Wrong password.');
  } else {
    alert(errorMessage);
  }
  console.log(error);
  document.getElementById('quickstart-sign-in').disabled = false;
  // [END_EXCLUDE]
});

 }
 ,

obser : function(){
  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      // User is signed in.
      var displayName = user.displayName;
      var email = user.email;
      var emailVerified = user.emailVerified;
      var photoURL = user.photoURL;
      var isAnonymous = user.isAnonymous;
      var uid = user.uid;
      var providerData = user.providerData;
      // ...
      document.getElementById('user').innerHTML=email;
    } else {
      // User is signed out.
      // ...
      document.getElementById('user').innerHTML='desconectado';
    }
  });
},
deslogeo : function()
{
  firebase.auth().signOut().then(function() {
    // Sign-out successful.
  }).catch(function(error) {
    // An error happened.
  })
},
  gool : function()
{
  var provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function(result) {
    // This gives you a Google Access Token. You can use it to access the Google API.
    var token = result.credential.accessToken;
    // The signed-in user info.
    var user = result.user;
    // ...
  }).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });
},
 agrinfor : function()
 {
  db.collection("users").add({
    first: "Ada",
    last: "Lovelace",
    born: 1815
})
.then(function(docRef) {
    console.log("Document written with ID: ", docRef.id);
})
.catch(function(error) {
    console.error("Error adding document: ", error);
});

 },
 leerinfor : function()
 {
  db.collection("users").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        console.log(`${doc.id} => ${doc.data()}`);
    });
});
 },
 agregardoc : function()
 {
   // Add a new document in collection "cities"
db.collection("personas").doc(document.getElementById("nickname").value).set({
  name: document.getElementById("name").value,
  apellido: document.getElementById("apellido").value ,
  nickname: document.getElementById("nickname").value

})
.then(function() {
  console.log("Document successfully written!");
})
.catch(function(error) {
  console.error("Error writing document: ", error);
});
var cityRef = db.collection('personas').doc('chidas');

var setWithMerge = cityRef.set({
    capital: true
}, { merge: true });


 },
 consultar : function()
 {
  db.collection("personas").where("nickname", "==", document.getElementById('nickname').value)
  .get()
  .then(function(querySnapshot) {
      querySnapshot.forEach(function(doc) {
          // doc.data() is never undefined for query doc snapshots
          console.log(doc.id, " => ", doc.data());
          document.getElementById('name').value = doc.data().name
          document.getElementById('apellido').value = doc.data().apellido
          document.getElementById('nickname').value = doc.data().nickname


      });
  })
  .catch(function(error) {
      console.log("Error getting documents: ", error);
  });

 },
 delete : function()
 {
  db.collection("personas").doc(document.getElementById('nickname').value).delete().then(function() {
    console.log("Document successfully deleted!");
    document.getElementById('name').value = ""
          document.getElementById('apellido').value = ""
          document.getElementById('nickname').value = ""
}).catch(function(error) {
    console.error("Error removing document: ", error);
});
 },

 yaho : function()
 {
  var provider = new firebase.auth.OAuthProvider('yahoo.com');
  firebase.auth().signInWithPopup(provider)
  .then(function(result) {

    // User is signed in.
    // IdP data available in result.additionalUserInfo.profile.
    // Yahoo OAuth access token can be retrieved by calling:
    // result.credential.accessToken
    // Yahoo OAuth ID token can be retrieved by calling:
    // result.credential.idToken
  })
  .catch(function(error) {
    // Handle error.
  });
 },
 jitjut: function()
 {
  var provider = new firebase.auth.GithubAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function(result) {
    // This gives you a GitHub Access Token. You can use it to access the GitHub API.
    var token = result.credential.accessToken;
    // The signed-in user info.
    var user = result.user;
    // ...
  }).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });
 },
 
  tuit: function()
 {
  var provider = new firebase.auth.TwitterAuthProvider();

  firebase.auth().signInWithPopup(provider).then(function(result) {
    // This gives you a the Twitter OAuth 1.0 Access Token and Secret.
    // You can use these server side with your app's credentials to access the Twitter API.
    var token = result.credential.accessToken;
    var secret = result.credential.secret;
    // The signed-in user info.
    var user = result.user;
    // ...
  }).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });
 },

 Riot: function()
  {
    fetch('https://la1.api.riotgames.com/lol/summoner/v4/summoners/by-name/'+usuario.value+apik)
    .then(lol=>lol.json()).then(lol=>{
      console.log(lol.summonerLevel)
      usuario.value = lol.name
      lev.value=lol.summonerLevel
    })
    
    fetch('https://la1.api.riotgames.com/lol/status/v3/shard-data'+apik)
    .then(leg=>leg.json()).then(leg=>{
      console.log(leg)
      so.value = leg.name
      region.value = leg.region_tag
      status.value = leg.status
    })
  }   
 
}
aplicacion.obser();
