var wms_layers = [];


        var lyr_BingMap_0 = new ol.layer.Tile({
            'title': 'Bing Map',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'http://ecn.dynamic.t0.tiles.virtualearth.net/comp/CompositionHandler/{q}?mkt=en-us&it=G,VE,BX,L,LA&shading=hill'
            })
        });

        var lyr_GoogleSatellite_1 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_Punto_2 = new ol.format.GeoJSON();
var features_Punto_2 = format_Punto_2.readFeatures(json_Punto_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Punto_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Punto_2.addFeatures(features_Punto_2);
var lyr_Punto_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Punto_2, 
                style: style_Punto_2,
                interactive: true,
                title: '<img src="styles/legend/Punto_2.png" /> Punto'
            });
var format_Lineas_3 = new ol.format.GeoJSON();
var features_Lineas_3 = format_Lineas_3.readFeatures(json_Lineas_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Lineas_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Lineas_3.addFeatures(features_Lineas_3);
var lyr_Lineas_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Lineas_3, 
                style: style_Lineas_3,
                interactive: true,
                title: '<img src="styles/legend/Lineas_3.png" /> Lineas'
            });
var format_Poligonos_4 = new ol.format.GeoJSON();
var features_Poligonos_4 = format_Poligonos_4.readFeatures(json_Poligonos_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Poligonos_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Poligonos_4.addFeatures(features_Poligonos_4);
var lyr_Poligonos_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Poligonos_4, 
                style: style_Poligonos_4,
                interactive: true,
                title: '<img src="styles/legend/Poligonos_4.png" /> Poligonos'
            });
var format_Poligonos2_5 = new ol.format.GeoJSON();
var features_Poligonos2_5 = format_Poligonos2_5.readFeatures(json_Poligonos2_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Poligonos2_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Poligonos2_5.addFeatures(features_Poligonos2_5);
var lyr_Poligonos2_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Poligonos2_5, 
                style: style_Poligonos2_5,
                interactive: true,
                title: '<img src="styles/legend/Poligonos2_5.png" /> Poligonos 2'
            });
var format_UAL_6 = new ol.format.GeoJSON();
var features_UAL_6 = format_UAL_6.readFeatures(json_UAL_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_UAL_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_UAL_6.addFeatures(features_UAL_6);
var lyr_UAL_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_UAL_6, 
                style: style_UAL_6,
                interactive: true,
                title: '<img src="styles/legend/UAL_6.png" /> UAL'
            });

lyr_BingMap_0.setVisible(true);lyr_GoogleSatellite_1.setVisible(true);lyr_Punto_2.setVisible(true);lyr_Lineas_3.setVisible(true);lyr_Poligonos_4.setVisible(true);lyr_Poligonos2_5.setVisible(true);lyr_UAL_6.setVisible(true);
var layersList = [lyr_BingMap_0,lyr_GoogleSatellite_1,lyr_Punto_2,lyr_Lineas_3,lyr_Poligonos_4,lyr_Poligonos2_5,lyr_UAL_6];
lyr_Punto_2.set('fieldAliases', {'id': 'id', });
lyr_Lineas_3.set('fieldAliases', {'id': 'id', });
lyr_Poligonos_4.set('fieldAliases', {'id': 'id', });
lyr_Poligonos2_5.set('fieldAliases', {'id': 'id', });
lyr_UAL_6.set('fieldAliases', {'id': 'id', });
lyr_Punto_2.set('fieldImages', {'id': '', });
lyr_Lineas_3.set('fieldImages', {'id': '', });
lyr_Poligonos_4.set('fieldImages', {'id': '', });
lyr_Poligonos2_5.set('fieldImages', {'id': '', });
lyr_UAL_6.set('fieldImages', {'id': '', });
lyr_Punto_2.set('fieldLabels', {'id': 'no label', });
lyr_Lineas_3.set('fieldLabels', {'id': 'no label', });
lyr_Poligonos_4.set('fieldLabels', {'id': 'no label', });
lyr_Poligonos2_5.set('fieldLabels', {'id': 'no label', });
lyr_UAL_6.set('fieldLabels', {'id': 'no label', });
lyr_UAL_6.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});