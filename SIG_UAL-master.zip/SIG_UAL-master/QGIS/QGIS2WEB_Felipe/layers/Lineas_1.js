var json_Lineas_1 = {
"type": "FeatureCollection",
"name": "Lineas_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [

]
}
