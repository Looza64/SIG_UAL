var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_Lineas_1 = new ol.format.GeoJSON();
var features_Lineas_1 = format_Lineas_1.readFeatures(json_Lineas_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Lineas_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Lineas_1.addFeatures(features_Lineas_1);
var lyr_Lineas_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Lineas_1, 
                style: style_Lineas_1,
                interactive: true,
                title: '<img src="styles/legend/Lineas_1.png" /> Lineas'
            });
var format_Poligno_2 = new ol.format.GeoJSON();
var features_Poligno_2 = format_Poligno_2.readFeatures(json_Poligno_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Poligno_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Poligno_2.addFeatures(features_Poligno_2);
var lyr_Poligno_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Poligno_2, 
                style: style_Poligno_2,
                interactive: true,
                title: '<img src="styles/legend/Poligno_2.png" /> Poligno'
            });
var format_Polingono2_3 = new ol.format.GeoJSON();
var features_Polingono2_3 = format_Polingono2_3.readFeatures(json_Polingono2_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Polingono2_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Polingono2_3.addFeatures(features_Polingono2_3);
var lyr_Polingono2_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Polingono2_3, 
                style: style_Polingono2_3,
                interactive: true,
                title: '<img src="styles/legend/Polingono2_3.png" /> Polingono2'
            });

lyr_GoogleSatellite_0.setVisible(true);lyr_Lineas_1.setVisible(true);lyr_Poligno_2.setVisible(true);lyr_Polingono2_3.setVisible(true);
var layersList = [lyr_GoogleSatellite_0,lyr_Lineas_1,lyr_Poligno_2,lyr_Polingono2_3];
lyr_Lineas_1.set('fieldAliases', {'id': 'id', });
lyr_Poligno_2.set('fieldAliases', {'id': 'id', });
lyr_Polingono2_3.set('fieldAliases', {'id': 'id', });
lyr_Lineas_1.set('fieldImages', {'id': '', });
lyr_Poligno_2.set('fieldImages', {'id': '', });
lyr_Polingono2_3.set('fieldImages', {'id': '', });
lyr_Lineas_1.set('fieldLabels', {'id': 'no label', });
lyr_Poligno_2.set('fieldLabels', {'id': 'no label', });
lyr_Polingono2_3.set('fieldLabels', {'id': 'no label', });
lyr_Polingono2_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});