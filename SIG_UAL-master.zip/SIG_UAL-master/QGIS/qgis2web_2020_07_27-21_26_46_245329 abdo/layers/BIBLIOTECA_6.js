var json_BIBLIOTECA_6 = {
"type": "FeatureCollection",
"name": "BIBLIOTECA_6",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "5" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432950381483863, 25.576852692006216 ], [ -103.432851603518046, 25.576847875875416 ], [ -103.432904107121487, 25.576647203586511 ], [ -103.432975298448213, 25.576655230484523 ], [ -103.432950381483863, 25.576852692006216 ] ] ] ] } }
]
}
