var json_EDIFICIOB_3 = {
"type": "FeatureCollection",
"name": "EDIFICIOB_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "2" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.43380156278397, 25.576523022170715 ], [ -103.432950555593038, 25.576437570484408 ], [ -103.432992303115597, 25.576105901497005 ], [ -103.433856155698109, 25.576198595105659 ], [ -103.43380156278397, 25.576523022170715 ] ] ] ] } }
]
}
