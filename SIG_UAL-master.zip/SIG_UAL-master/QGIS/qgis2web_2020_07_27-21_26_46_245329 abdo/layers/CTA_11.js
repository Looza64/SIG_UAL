var json_CTA_11 = {
"type": "FeatureCollection",
"name": "CTA_11",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "10" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433957230938475, 25.576836044944525 ], [ -103.433566249332827, 25.576788250066031 ], [ -103.433583108909232, 25.576672383614721 ], [ -103.433974090514894, 25.5767187302087 ], [ -103.433957230938475, 25.576836044944525 ] ] ] ] } }
]
}
