var json_LABCOMIDAYBEBIDA_18 = {
"type": "FeatureCollection",
"name": "LABCOMIDAYBEBIDA_18",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "17" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432344659149109, 25.576788536776228 ], [ -103.432163775063827, 25.576770589306765 ], [ -103.43216920158639, 25.57672979959343 ], [ -103.432256930367757, 25.576740404920233 ], [ -103.432297629286936, 25.576740404920233 ], [ -103.432350085671658, 25.576726536415766 ], [ -103.432344659149109, 25.576788536776228 ] ] ] ] } }
]
}
