var json_CANCHATECHADA_22 = {
"type": "FeatureCollection",
"name": "CANCHATECHADA_22",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "21" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433475279119506, 25.576926972679725 ], [ -103.433162037281889, 25.576890049028215 ], [ -103.43319585316209, 25.576613923968907 ], [ -103.433510874782883, 25.576650847705587 ], [ -103.433475279119506, 25.576926972679725 ] ] ] ] } }
]
}
