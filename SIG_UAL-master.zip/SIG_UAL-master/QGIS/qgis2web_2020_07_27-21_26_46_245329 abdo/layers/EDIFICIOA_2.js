var json_EDIFICIOA_2 = {
"type": "FeatureCollection",
"name": "EDIFICIOA_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432377752712853, 25.576374542806679 ], [ -103.431521928500089, 25.576284746006365 ], [ -103.431560464674774, 25.575948731575348 ], [ -103.432417894561482, 25.576038528627709 ], [ -103.432377752712853, 25.576374542806679 ] ] ] ] } }
]
}
