var json_CENTROARTESYARQUI_20 = {
"type": "FeatureCollection",
"name": "CENTROARTESYARQUI_20",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "19" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.434260163496688, 25.576959080193514 ], [ -103.434055488432335, 25.576937407622648 ], [ -103.434113331385291, 25.576577802911125 ], [ -103.434305547967483, 25.576594659406105 ], [ -103.434260163496688, 25.576959080193514 ] ] ] ] } }
]
}
