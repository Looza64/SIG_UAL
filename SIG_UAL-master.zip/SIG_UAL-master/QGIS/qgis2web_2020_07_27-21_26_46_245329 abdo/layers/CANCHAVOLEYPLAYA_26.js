var json_CANCHAVOLEYPLAYA_26 = {
"type": "FeatureCollection",
"name": "CANCHAVOLEYPLAYA_26",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "25" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.429882467594055, 25.576587186534816 ], [ -103.429617531393106, 25.576708122226872 ], [ -103.429513965423652, 25.576522011560289 ], [ -103.42978291580944, 25.576403972349439 ], [ -103.429882467594055, 25.576587186534816 ] ] ] ] } }
]
}
