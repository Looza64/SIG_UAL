var wms_layers = [];


        var lyr_GooglecnSatellite_0 = new ol.layer.Tile({
            'title': 'Google.cn Satellite',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="https://www.google.com/intl/zh-CN_cn/permissions/geoguidelines/attr-guide.html">地图数据 ©2016 Google</a>',
                url: 'http://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}'
            })
        });
var format_Limite_1 = new ol.format.GeoJSON();
var features_Limite_1 = format_Limite_1.readFeatures(json_Limite_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Limite_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Limite_1.addFeatures(features_Limite_1);
var lyr_Limite_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Limite_1, 
                style: style_Limite_1,
                interactive: true,
                title: '<img src="styles/legend/Limite_1.png" /> Limite'
            });
var format_EDIFICIOA_2 = new ol.format.GeoJSON();
var features_EDIFICIOA_2 = format_EDIFICIOA_2.readFeatures(json_EDIFICIOA_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_EDIFICIOA_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_EDIFICIOA_2.addFeatures(features_EDIFICIOA_2);
var lyr_EDIFICIOA_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_EDIFICIOA_2, 
                style: style_EDIFICIOA_2,
                interactive: true,
                title: '<img src="styles/legend/EDIFICIOA_2.png" /> EDIFICIO A'
            });
var format_EDIFICIOB_3 = new ol.format.GeoJSON();
var features_EDIFICIOB_3 = format_EDIFICIOB_3.readFeatures(json_EDIFICIOB_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_EDIFICIOB_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_EDIFICIOB_3.addFeatures(features_EDIFICIOB_3);
var lyr_EDIFICIOB_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_EDIFICIOB_3, 
                style: style_EDIFICIOB_3,
                interactive: true,
                title: '<img src="styles/legend/EDIFICIOB_3.png" /> EDIFICIO B'
            });
var format_EDIFICIOC_4 = new ol.format.GeoJSON();
var features_EDIFICIOC_4 = format_EDIFICIOC_4.readFeatures(json_EDIFICIOC_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_EDIFICIOC_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_EDIFICIOC_4.addFeatures(features_EDIFICIOC_4);
var lyr_EDIFICIOC_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_EDIFICIOC_4, 
                style: style_EDIFICIOC_4,
                interactive: true,
                title: '<img src="styles/legend/EDIFICIOC_4.png" /> EDIFICIO C'
            });
var format_CAFETERIA_5 = new ol.format.GeoJSON();
var features_CAFETERIA_5 = format_CAFETERIA_5.readFeatures(json_CAFETERIA_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CAFETERIA_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CAFETERIA_5.addFeatures(features_CAFETERIA_5);
var lyr_CAFETERIA_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CAFETERIA_5, 
                style: style_CAFETERIA_5,
                interactive: true,
                title: '<img src="styles/legend/CAFETERIA_5.png" /> CAFETERIA'
            });
var format_BIBLIOTECA_6 = new ol.format.GeoJSON();
var features_BIBLIOTECA_6 = format_BIBLIOTECA_6.readFeatures(json_BIBLIOTECA_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_BIBLIOTECA_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_BIBLIOTECA_6.addFeatures(features_BIBLIOTECA_6);
var lyr_BIBLIOTECA_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_BIBLIOTECA_6, 
                style: style_BIBLIOTECA_6,
                interactive: true,
                title: '<img src="styles/legend/BIBLIOTECA_6.png" /> BIBLIOTECA'
            });
var format_SERVESCOLARES_7 = new ol.format.GeoJSON();
var features_SERVESCOLARES_7 = format_SERVESCOLARES_7.readFeatures(json_SERVESCOLARES_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_SERVESCOLARES_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_SERVESCOLARES_7.addFeatures(features_SERVESCOLARES_7);
var lyr_SERVESCOLARES_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_SERVESCOLARES_7, 
                style: style_SERVESCOLARES_7,
                interactive: true,
                title: '<img src="styles/legend/SERVESCOLARES_7.png" /> SERV ESCOLARES'
            });
var format_PAPELERIA_8 = new ol.format.GeoJSON();
var features_PAPELERIA_8 = format_PAPELERIA_8.readFeatures(json_PAPELERIA_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PAPELERIA_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PAPELERIA_8.addFeatures(features_PAPELERIA_8);
var lyr_PAPELERIA_8 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PAPELERIA_8, 
                style: style_PAPELERIA_8,
                interactive: true,
                title: '<img src="styles/legend/PAPELERIA_8.png" /> PAPELERIA'
            });
var format_ESTADIOPEQUE_9 = new ol.format.GeoJSON();
var features_ESTADIOPEQUE_9 = format_ESTADIOPEQUE_9.readFeatures(json_ESTADIOPEQUE_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ESTADIOPEQUE_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ESTADIOPEQUE_9.addFeatures(features_ESTADIOPEQUE_9);
var lyr_ESTADIOPEQUE_9 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ESTADIOPEQUE_9, 
                style: style_ESTADIOPEQUE_9,
                interactive: true,
                title: '<img src="styles/legend/ESTADIOPEQUE_9.png" /> ESTADIO PEQUE'
            });
var format_CIP_10 = new ol.format.GeoJSON();
var features_CIP_10 = format_CIP_10.readFeatures(json_CIP_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CIP_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CIP_10.addFeatures(features_CIP_10);
var lyr_CIP_10 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CIP_10, 
                style: style_CIP_10,
                interactive: true,
                title: '<img src="styles/legend/CIP_10.png" /> CIP'
            });
var format_CTA_11 = new ol.format.GeoJSON();
var features_CTA_11 = format_CTA_11.readFeatures(json_CTA_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CTA_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CTA_11.addFeatures(features_CTA_11);
var lyr_CTA_11 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CTA_11, 
                style: style_CTA_11,
                interactive: true,
                title: '<img src="styles/legend/CTA_11.png" /> CTA'
            });
var format_SECU_12 = new ol.format.GeoJSON();
var features_SECU_12 = format_SECU_12.readFeatures(json_SECU_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_SECU_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_SECU_12.addFeatures(features_SECU_12);
var lyr_SECU_12 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_SECU_12, 
                style: style_SECU_12,
                interactive: true,
                title: '<img src="styles/legend/SECU_12.png" /> SECU'
            });
var format_CAFESECU_13 = new ol.format.GeoJSON();
var features_CAFESECU_13 = format_CAFESECU_13.readFeatures(json_CAFESECU_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CAFESECU_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CAFESECU_13.addFeatures(features_CAFESECU_13);
var lyr_CAFESECU_13 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CAFESECU_13, 
                style: style_CAFESECU_13,
                interactive: true,
                title: '<img src="styles/legend/CAFESECU_13.png" /> CAFE SECU'
            });
var format_AUDITORIOGYM_14 = new ol.format.GeoJSON();
var features_AUDITORIOGYM_14 = format_AUDITORIOGYM_14.readFeatures(json_AUDITORIOGYM_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_AUDITORIOGYM_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_AUDITORIOGYM_14.addFeatures(features_AUDITORIOGYM_14);
var lyr_AUDITORIOGYM_14 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_AUDITORIOGYM_14, 
                style: style_AUDITORIOGYM_14,
                interactive: true,
                title: '<img src="styles/legend/AUDITORIOGYM_14.png" /> AUDITORIO GYM'
            });
var format_ALBERCA_15 = new ol.format.GeoJSON();
var features_ALBERCA_15 = format_ALBERCA_15.readFeatures(json_ALBERCA_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ALBERCA_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ALBERCA_15.addFeatures(features_ALBERCA_15);
var lyr_ALBERCA_15 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ALBERCA_15, 
                style: style_ALBERCA_15,
                interactive: true,
                title: '<img src="styles/legend/ALBERCA_15.png" /> ALBERCA'
            });
var format_GYM_16 = new ol.format.GeoJSON();
var features_GYM_16 = format_GYM_16.readFeatures(json_GYM_16, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_GYM_16 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_GYM_16.addFeatures(features_GYM_16);
var lyr_GYM_16 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_GYM_16, 
                style: style_GYM_16,
                interactive: true,
                title: '<img src="styles/legend/GYM_16.png" /> GYM'
            });
var format_LABSONIDO_17 = new ol.format.GeoJSON();
var features_LABSONIDO_17 = format_LABSONIDO_17.readFeatures(json_LABSONIDO_17, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_LABSONIDO_17 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_LABSONIDO_17.addFeatures(features_LABSONIDO_17);
var lyr_LABSONIDO_17 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_LABSONIDO_17, 
                style: style_LABSONIDO_17,
                interactive: true,
                title: '<img src="styles/legend/LABSONIDO_17.png" /> LAB SONIDO'
            });
var format_LABCOMIDAYBEBIDA_18 = new ol.format.GeoJSON();
var features_LABCOMIDAYBEBIDA_18 = format_LABCOMIDAYBEBIDA_18.readFeatures(json_LABCOMIDAYBEBIDA_18, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_LABCOMIDAYBEBIDA_18 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_LABCOMIDAYBEBIDA_18.addFeatures(features_LABCOMIDAYBEBIDA_18);
var lyr_LABCOMIDAYBEBIDA_18 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_LABCOMIDAYBEBIDA_18, 
                style: style_LABCOMIDAYBEBIDA_18,
                interactive: true,
                title: '<img src="styles/legend/LABCOMIDAYBEBIDA_18.png" /> LAB COMIDA Y BEBIDA'
            });
var format_ALMACEN_19 = new ol.format.GeoJSON();
var features_ALMACEN_19 = format_ALMACEN_19.readFeatures(json_ALMACEN_19, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ALMACEN_19 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ALMACEN_19.addFeatures(features_ALMACEN_19);
var lyr_ALMACEN_19 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ALMACEN_19, 
                style: style_ALMACEN_19,
                interactive: true,
                title: '<img src="styles/legend/ALMACEN_19.png" /> ALMACEN'
            });
var format_CENTROARTESYARQUI_20 = new ol.format.GeoJSON();
var features_CENTROARTESYARQUI_20 = format_CENTROARTESYARQUI_20.readFeatures(json_CENTROARTESYARQUI_20, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CENTROARTESYARQUI_20 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CENTROARTESYARQUI_20.addFeatures(features_CENTROARTESYARQUI_20);
var lyr_CENTROARTESYARQUI_20 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CENTROARTESYARQUI_20, 
                style: style_CENTROARTESYARQUI_20,
                interactive: true,
                title: '<img src="styles/legend/CENTROARTESYARQUI_20.png" /> CENTRO ARTES Y ARQUI'
            });
var format_PLAZADELESTUDIANTE_21 = new ol.format.GeoJSON();
var features_PLAZADELESTUDIANTE_21 = format_PLAZADELESTUDIANTE_21.readFeatures(json_PLAZADELESTUDIANTE_21, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PLAZADELESTUDIANTE_21 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PLAZADELESTUDIANTE_21.addFeatures(features_PLAZADELESTUDIANTE_21);
var lyr_PLAZADELESTUDIANTE_21 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PLAZADELESTUDIANTE_21, 
                style: style_PLAZADELESTUDIANTE_21,
                interactive: true,
                title: '<img src="styles/legend/PLAZADELESTUDIANTE_21.png" /> PLAZA DEL ESTUDIANTE'
            });
var format_CANCHATECHADA_22 = new ol.format.GeoJSON();
var features_CANCHATECHADA_22 = format_CANCHATECHADA_22.readFeatures(json_CANCHATECHADA_22, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CANCHATECHADA_22 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CANCHATECHADA_22.addFeatures(features_CANCHATECHADA_22);
var lyr_CANCHATECHADA_22 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CANCHATECHADA_22, 
                style: style_CANCHATECHADA_22,
                interactive: true,
                title: '<img src="styles/legend/CANCHATECHADA_22.png" /> CANCHA TECHADA'
            });
var format_CANCHASAZULES_23 = new ol.format.GeoJSON();
var features_CANCHASAZULES_23 = format_CANCHASAZULES_23.readFeatures(json_CANCHASAZULES_23, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CANCHASAZULES_23 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CANCHASAZULES_23.addFeatures(features_CANCHASAZULES_23);
var lyr_CANCHASAZULES_23 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CANCHASAZULES_23, 
                style: style_CANCHASAZULES_23,
                interactive: true,
                title: '<img src="styles/legend/CANCHASAZULES_23.png" /> CANCHAS AZULES'
            });
var format_CANCHAFUT_24 = new ol.format.GeoJSON();
var features_CANCHAFUT_24 = format_CANCHAFUT_24.readFeatures(json_CANCHAFUT_24, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CANCHAFUT_24 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CANCHAFUT_24.addFeatures(features_CANCHAFUT_24);
var lyr_CANCHAFUT_24 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CANCHAFUT_24, 
                style: style_CANCHAFUT_24,
                interactive: true,
                title: '<img src="styles/legend/CANCHAFUT_24.png" /> CANCHA FUT'
            });
var format_CANCHAATLETISMOYTOCHITO_25 = new ol.format.GeoJSON();
var features_CANCHAATLETISMOYTOCHITO_25 = format_CANCHAATLETISMOYTOCHITO_25.readFeatures(json_CANCHAATLETISMOYTOCHITO_25, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CANCHAATLETISMOYTOCHITO_25 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CANCHAATLETISMOYTOCHITO_25.addFeatures(features_CANCHAATLETISMOYTOCHITO_25);
var lyr_CANCHAATLETISMOYTOCHITO_25 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CANCHAATLETISMOYTOCHITO_25, 
                style: style_CANCHAATLETISMOYTOCHITO_25,
                interactive: true,
                title: '<img src="styles/legend/CANCHAATLETISMOYTOCHITO_25.png" /> CANCHA ATLETISMO Y TOCHITO'
            });
var format_CANCHAVOLEYPLAYA_26 = new ol.format.GeoJSON();
var features_CANCHAVOLEYPLAYA_26 = format_CANCHAVOLEYPLAYA_26.readFeatures(json_CANCHAVOLEYPLAYA_26, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CANCHAVOLEYPLAYA_26 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CANCHAVOLEYPLAYA_26.addFeatures(features_CANCHAVOLEYPLAYA_26);
var lyr_CANCHAVOLEYPLAYA_26 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_CANCHAVOLEYPLAYA_26, 
                style: style_CANCHAVOLEYPLAYA_26,
                interactive: true,
                title: '<img src="styles/legend/CANCHAVOLEYPLAYA_26.png" /> CANCHA VOLEY PLAYA'
            });
var format_JAULAHALCONES_27 = new ol.format.GeoJSON();
var features_JAULAHALCONES_27 = format_JAULAHALCONES_27.readFeatures(json_JAULAHALCONES_27, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_JAULAHALCONES_27 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_JAULAHALCONES_27.addFeatures(features_JAULAHALCONES_27);
var lyr_JAULAHALCONES_27 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_JAULAHALCONES_27, 
                style: style_JAULAHALCONES_27,
                interactive: true,
                title: '<img src="styles/legend/JAULAHALCONES_27.png" /> JAULA HALCONES'
            });
var format_PRIMARIA_28 = new ol.format.GeoJSON();
var features_PRIMARIA_28 = format_PRIMARIA_28.readFeatures(json_PRIMARIA_28, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PRIMARIA_28 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PRIMARIA_28.addFeatures(features_PRIMARIA_28);
var lyr_PRIMARIA_28 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PRIMARIA_28, 
                style: style_PRIMARIA_28,
                interactive: true,
                title: '<img src="styles/legend/PRIMARIA_28.png" /> PRIMARIA'
            });
var format_COCINA_29 = new ol.format.GeoJSON();
var features_COCINA_29 = format_COCINA_29.readFeatures(json_COCINA_29, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_COCINA_29 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_COCINA_29.addFeatures(features_COCINA_29);
var lyr_COCINA_29 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_COCINA_29, 
                style: style_COCINA_29,
                interactive: true,
                title: '<img src="styles/legend/COCINA_29.png" /> COCINA'
            });

lyr_GooglecnSatellite_0.setVisible(true);lyr_Limite_1.setVisible(true);lyr_EDIFICIOA_2.setVisible(true);lyr_EDIFICIOB_3.setVisible(true);lyr_EDIFICIOC_4.setVisible(true);lyr_CAFETERIA_5.setVisible(true);lyr_BIBLIOTECA_6.setVisible(true);lyr_SERVESCOLARES_7.setVisible(true);lyr_PAPELERIA_8.setVisible(true);lyr_ESTADIOPEQUE_9.setVisible(true);lyr_CIP_10.setVisible(true);lyr_CTA_11.setVisible(true);lyr_SECU_12.setVisible(true);lyr_CAFESECU_13.setVisible(true);lyr_AUDITORIOGYM_14.setVisible(true);lyr_ALBERCA_15.setVisible(true);lyr_GYM_16.setVisible(true);lyr_LABSONIDO_17.setVisible(true);lyr_LABCOMIDAYBEBIDA_18.setVisible(true);lyr_ALMACEN_19.setVisible(true);lyr_CENTROARTESYARQUI_20.setVisible(true);lyr_PLAZADELESTUDIANTE_21.setVisible(true);lyr_CANCHATECHADA_22.setVisible(true);lyr_CANCHASAZULES_23.setVisible(true);lyr_CANCHAFUT_24.setVisible(true);lyr_CANCHAATLETISMOYTOCHITO_25.setVisible(true);lyr_CANCHAVOLEYPLAYA_26.setVisible(true);lyr_JAULAHALCONES_27.setVisible(true);lyr_PRIMARIA_28.setVisible(true);lyr_COCINA_29.setVisible(true);
var layersList = [lyr_GooglecnSatellite_0,lyr_Limite_1,lyr_EDIFICIOA_2,lyr_EDIFICIOB_3,lyr_EDIFICIOC_4,lyr_CAFETERIA_5,lyr_BIBLIOTECA_6,lyr_SERVESCOLARES_7,lyr_PAPELERIA_8,lyr_ESTADIOPEQUE_9,lyr_CIP_10,lyr_CTA_11,lyr_SECU_12,lyr_CAFESECU_13,lyr_AUDITORIOGYM_14,lyr_ALBERCA_15,lyr_GYM_16,lyr_LABSONIDO_17,lyr_LABCOMIDAYBEBIDA_18,lyr_ALMACEN_19,lyr_CENTROARTESYARQUI_20,lyr_PLAZADELESTUDIANTE_21,lyr_CANCHATECHADA_22,lyr_CANCHASAZULES_23,lyr_CANCHAFUT_24,lyr_CANCHAATLETISMOYTOCHITO_25,lyr_CANCHAVOLEYPLAYA_26,lyr_JAULAHALCONES_27,lyr_PRIMARIA_28,lyr_COCINA_29];
lyr_Limite_1.set('fieldAliases', {'id': 'id', });
lyr_EDIFICIOA_2.set('fieldAliases', {'id': 'id', });
lyr_EDIFICIOB_3.set('fieldAliases', {'id': 'id', });
lyr_EDIFICIOC_4.set('fieldAliases', {'id': 'id', });
lyr_CAFETERIA_5.set('fieldAliases', {'id': 'id', });
lyr_BIBLIOTECA_6.set('fieldAliases', {'id': 'id', });
lyr_SERVESCOLARES_7.set('fieldAliases', {'id': 'id', });
lyr_PAPELERIA_8.set('fieldAliases', {'id': 'id', });
lyr_ESTADIOPEQUE_9.set('fieldAliases', {'id': 'id', });
lyr_CIP_10.set('fieldAliases', {'id': 'id', });
lyr_CTA_11.set('fieldAliases', {'id': 'id', });
lyr_SECU_12.set('fieldAliases', {'id': 'id', });
lyr_CAFESECU_13.set('fieldAliases', {'id': 'id', });
lyr_AUDITORIOGYM_14.set('fieldAliases', {'id': 'id', });
lyr_ALBERCA_15.set('fieldAliases', {'id': 'id', });
lyr_GYM_16.set('fieldAliases', {'id': 'id', });
lyr_LABSONIDO_17.set('fieldAliases', {'id': 'id', });
lyr_LABCOMIDAYBEBIDA_18.set('fieldAliases', {'id': 'id', });
lyr_ALMACEN_19.set('fieldAliases', {'id': 'id', });
lyr_CENTROARTESYARQUI_20.set('fieldAliases', {'id': 'id', });
lyr_PLAZADELESTUDIANTE_21.set('fieldAliases', {'id': 'id', });
lyr_CANCHATECHADA_22.set('fieldAliases', {'id': 'id', });
lyr_CANCHASAZULES_23.set('fieldAliases', {'id': 'id', });
lyr_CANCHAFUT_24.set('fieldAliases', {'id': 'id', });
lyr_CANCHAATLETISMOYTOCHITO_25.set('fieldAliases', {'id': 'id', });
lyr_CANCHAVOLEYPLAYA_26.set('fieldAliases', {'id': 'id', });
lyr_JAULAHALCONES_27.set('fieldAliases', {'id': 'id', });
lyr_PRIMARIA_28.set('fieldAliases', {'id': 'id', });
lyr_COCINA_29.set('fieldAliases', {'id': 'id', });
lyr_Limite_1.set('fieldImages', {'id': 'TextEdit', });
lyr_EDIFICIOA_2.set('fieldImages', {'id': 'TextEdit', });
lyr_EDIFICIOB_3.set('fieldImages', {'id': 'TextEdit', });
lyr_EDIFICIOC_4.set('fieldImages', {'id': 'TextEdit', });
lyr_CAFETERIA_5.set('fieldImages', {'id': 'TextEdit', });
lyr_BIBLIOTECA_6.set('fieldImages', {'id': 'TextEdit', });
lyr_SERVESCOLARES_7.set('fieldImages', {'id': 'TextEdit', });
lyr_PAPELERIA_8.set('fieldImages', {'id': 'TextEdit', });
lyr_ESTADIOPEQUE_9.set('fieldImages', {'id': 'TextEdit', });
lyr_CIP_10.set('fieldImages', {'id': 'TextEdit', });
lyr_CTA_11.set('fieldImages', {'id': 'TextEdit', });
lyr_SECU_12.set('fieldImages', {'id': 'TextEdit', });
lyr_CAFESECU_13.set('fieldImages', {'id': 'TextEdit', });
lyr_AUDITORIOGYM_14.set('fieldImages', {'id': 'TextEdit', });
lyr_ALBERCA_15.set('fieldImages', {'id': 'TextEdit', });
lyr_GYM_16.set('fieldImages', {'id': 'TextEdit', });
lyr_LABSONIDO_17.set('fieldImages', {'id': 'TextEdit', });
lyr_LABCOMIDAYBEBIDA_18.set('fieldImages', {'id': 'TextEdit', });
lyr_ALMACEN_19.set('fieldImages', {'id': 'TextEdit', });
lyr_CENTROARTESYARQUI_20.set('fieldImages', {'id': 'TextEdit', });
lyr_PLAZADELESTUDIANTE_21.set('fieldImages', {'id': 'TextEdit', });
lyr_CANCHATECHADA_22.set('fieldImages', {'id': 'TextEdit', });
lyr_CANCHASAZULES_23.set('fieldImages', {'id': 'TextEdit', });
lyr_CANCHAFUT_24.set('fieldImages', {'id': 'TextEdit', });
lyr_CANCHAATLETISMOYTOCHITO_25.set('fieldImages', {'id': 'TextEdit', });
lyr_CANCHAVOLEYPLAYA_26.set('fieldImages', {'id': 'TextEdit', });
lyr_JAULAHALCONES_27.set('fieldImages', {'id': 'TextEdit', });
lyr_PRIMARIA_28.set('fieldImages', {'id': 'TextEdit', });
lyr_COCINA_29.set('fieldImages', {'id': 'TextEdit', });
lyr_Limite_1.set('fieldLabels', {'id': 'no label', });
lyr_EDIFICIOA_2.set('fieldLabels', {'id': 'no label', });
lyr_EDIFICIOB_3.set('fieldLabels', {'id': 'no label', });
lyr_EDIFICIOC_4.set('fieldLabels', {'id': 'no label', });
lyr_CAFETERIA_5.set('fieldLabels', {'id': 'no label', });
lyr_BIBLIOTECA_6.set('fieldLabels', {'id': 'no label', });
lyr_SERVESCOLARES_7.set('fieldLabels', {'id': 'no label', });
lyr_PAPELERIA_8.set('fieldLabels', {'id': 'no label', });
lyr_ESTADIOPEQUE_9.set('fieldLabels', {'id': 'no label', });
lyr_CIP_10.set('fieldLabels', {'id': 'no label', });
lyr_CTA_11.set('fieldLabels', {'id': 'no label', });
lyr_SECU_12.set('fieldLabels', {'id': 'no label', });
lyr_CAFESECU_13.set('fieldLabels', {'id': 'no label', });
lyr_AUDITORIOGYM_14.set('fieldLabels', {'id': 'no label', });
lyr_ALBERCA_15.set('fieldLabels', {'id': 'no label', });
lyr_GYM_16.set('fieldLabels', {'id': 'no label', });
lyr_LABSONIDO_17.set('fieldLabels', {'id': 'no label', });
lyr_LABCOMIDAYBEBIDA_18.set('fieldLabels', {'id': 'no label', });
lyr_ALMACEN_19.set('fieldLabels', {'id': 'no label', });
lyr_CENTROARTESYARQUI_20.set('fieldLabels', {'id': 'no label', });
lyr_PLAZADELESTUDIANTE_21.set('fieldLabels', {'id': 'no label', });
lyr_CANCHATECHADA_22.set('fieldLabels', {'id': 'no label', });
lyr_CANCHASAZULES_23.set('fieldLabels', {'id': 'no label', });
lyr_CANCHAFUT_24.set('fieldLabels', {'id': 'no label', });
lyr_CANCHAATLETISMOYTOCHITO_25.set('fieldLabels', {'id': 'no label', });
lyr_CANCHAVOLEYPLAYA_26.set('fieldLabels', {'id': 'no label', });
lyr_JAULAHALCONES_27.set('fieldLabels', {'id': 'no label', });
lyr_PRIMARIA_28.set('fieldLabels', {'id': 'no label', });
lyr_COCINA_29.set('fieldLabels', {'id': 'no label', });
lyr_COCINA_29.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});