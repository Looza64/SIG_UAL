var json_CAFESECU_13 = {
"type": "FeatureCollection",
"name": "CAFESECU_13",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "12" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433324146470738, 25.577972248025596 ], [ -103.433374794014625, 25.577906985132721 ], [ -103.433492368670045, 25.577970616453708 ], [ -103.433432676921925, 25.578037510882886 ], [ -103.433324146470738, 25.577972248025596 ] ] ] ] } }
]
}
