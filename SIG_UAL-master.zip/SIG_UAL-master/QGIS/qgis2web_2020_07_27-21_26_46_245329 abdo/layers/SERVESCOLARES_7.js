var json_SERVESCOLARES_7 = {
"type": "FeatureCollection",
"name": "SERVESCOLARES_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "6" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433079415763544, 25.576940185015356 ], [ -103.432845374276937, 25.576916907065041 ], [ -103.432852493409612, 25.576842257055908 ], [ -103.433083865221477, 25.576867140397457 ], [ -103.433079415763544, 25.576940185015356 ] ] ] ] } }
]
}
