var json_PAPELERIA_8 = {
"type": "FeatureCollection",
"name": "PAPELERIA_8",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "7" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.431913657788385, 25.576544459244367 ], [ -103.431860264293348, 25.576476230530957 ], [ -103.431908318438872, 25.576434490592987 ], [ -103.431952813018086, 25.576485862822263 ], [ -103.431948363560139, 25.576523589289099 ], [ -103.431913657788385, 25.576544459244367 ] ] ] ] } }
]
}
