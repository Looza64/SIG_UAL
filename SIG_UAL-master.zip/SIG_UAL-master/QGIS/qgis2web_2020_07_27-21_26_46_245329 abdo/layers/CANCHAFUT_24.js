var json_CANCHAFUT_24 = {
"type": "FeatureCollection",
"name": "CANCHAFUT_24",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "23" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.430387355322523, 25.5764790719643 ], [ -103.430088351750243, 25.575902738470674 ], [ -103.43108503032451, 25.575459650109917 ], [ -103.431343098883929, 25.575952505539174 ], [ -103.43133064040174, 25.576072909651614 ], [ -103.430387355322523, 25.5764790719643 ] ] ] ] } }
]
}
