var json_PRIMARIA_28 = {
"type": "FeatureCollection",
"name": "PRIMARIA_28",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "27" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432903543121697, 25.57877921751135 ], [ -103.432797568641334, 25.57871549203692 ], [ -103.43332744104319, 25.577991336535209 ], [ -103.433425387153846, 25.57803333767399 ], [ -103.432903543121697, 25.57877921751135 ] ] ] ] } }
]
}
