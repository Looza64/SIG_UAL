var json_EdificiodeArquitecturayartes_5 = {
"type": "FeatureCollection",
"name": "EdificiodeArquitecturayartes_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "5" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.434298805802044, 25.576614889825883 ], [ -103.434257582413935, 25.576956010829448 ], [ -103.434128535286064, 25.576943077349412 ], [ -103.434159004746817, 25.576692490897887 ], [ -103.434092688861639, 25.576676324012038 ], [ -103.434107027431409, 25.576590639480568 ], [ -103.434297013480801, 25.576616506515396 ], [ -103.434298805802044, 25.576614889825883 ] ] ] ] } }
]
}
