var json_Cafeteria2_19 = {
"type": "FeatureCollection",
"name": "Cafeteria2_19",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "20" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433177806158923, 25.577588547768212 ], [ -103.433218557883521, 25.577694227303528 ], [ -103.433373923833557, 25.577643684928713 ], [ -103.433320437195022, 25.577531113199019 ], [ -103.433177806158923, 25.577588547768212 ] ] ] ] } }
]
}
