var json_CentrodeTecnologiaAvanzado_6 = {
"type": "FeatureCollection",
"name": "CentrodeTecnologiaAvanzado_6",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "6" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433952887806413, 25.576828292652856 ], [ -103.433571123386372, 25.576784642105562 ], [ -103.433583669634928, 25.576677940700719 ], [ -103.433958264770069, 25.576721591286923 ], [ -103.433954680127641, 25.576828292652856 ], [ -103.433952887806413, 25.576828292652856 ] ] ] ] } }
]
}
