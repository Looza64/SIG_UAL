var json_Laboratoriodemusica_16 = {
"type": "FeatureCollection",
"name": "Laboratoriodemusica_16",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "16" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432363098883513, 25.576796767259182 ], [ -103.432349656474372, 25.57690831861489 ], [ -103.432273482822481, 25.576898618501129 ], [ -103.432287821392237, 25.576794342228556 ], [ -103.432363098883513, 25.576795150572103 ], [ -103.432363098883513, 25.576796767259182 ] ] ] ] } }
]
}
