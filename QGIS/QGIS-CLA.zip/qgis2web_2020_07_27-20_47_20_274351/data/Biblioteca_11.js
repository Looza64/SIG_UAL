var json_Biblioteca_11 = {
"type": "FeatureCollection",
"name": "Biblioteca_11",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "11" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.432952772565201, 25.576854159636333 ], [ -103.432974280419842, 25.576660157124 ], [ -103.432884664358809, 25.576642373544637 ], [ -103.432847025613171, 25.576844459518181 ], [ -103.432947395601545, 25.576854159636333 ], [ -103.432952772565201, 25.576854159636333 ] ] ] ] } }
]
}
