var json_Canchasdebasquetrapidasyvoleyball_23 = {
"type": "FeatureCollection",
"name": "Canchasdebasquetrapidasyvoleyball_23",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "25" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.43042579125725, 25.576588225081917 ], [ -103.430030159930965, 25.576758232665849 ], [ -103.429710938088292, 25.57607207445146 ], [ -103.430101475449007, 25.575928103255514 ], [ -103.43042579125725, 25.576588225081917 ] ] ] ] } }
]
}
