var json_ServiciosEscolares_12 = {
"type": "FeatureCollection",
"name": "ServiciosEscolares_12",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "12" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433083612014329, 25.576936610608872 ], [ -103.432830894722173, 25.576915593699692 ], [ -103.432843440970728, 25.576852542950029 ], [ -103.433083612014329, 25.576870326498167 ], [ -103.433083612014329, 25.576936610608872 ] ] ] ] } }
]
}
