var json_Canchadefutbol2_24 = {
"type": "FeatureCollection",
"name": "Canchadefutbol2_24",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "26" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.431310443278718, 25.576032252648627 ], [ -103.430388435509713, 25.576421280462739 ], [ -103.430125247288359, 25.57591278716065 ], [ -103.431045557068842, 25.575514568006398 ], [ -103.431310443278718, 25.576032252648627 ] ] ] ] } }
]
}
