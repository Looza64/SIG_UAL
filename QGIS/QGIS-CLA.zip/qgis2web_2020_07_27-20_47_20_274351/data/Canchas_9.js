var json_Canchas_9 = {
"type": "FeatureCollection",
"name": "Canchas_9",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "9" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433481507325325, 25.576925293812081 ], [ -103.43316068182682, 25.57689296010107 ], [ -103.433192943608773, 25.576622973273231 ], [ -103.433513769107307, 25.576661773812901 ], [ -103.433477922682897, 25.576931760553233 ], [ -103.433481507325325, 25.576925293812081 ] ] ] ] } }
]
}
