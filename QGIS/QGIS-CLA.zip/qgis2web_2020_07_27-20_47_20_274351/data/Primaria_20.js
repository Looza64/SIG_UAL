var json_Primaria_20 = {
"type": "FeatureCollection",
"name": "Primaria_20",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "21" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -103.433427834969251, 25.578053958210813 ], [ -103.433312371749565, 25.577983505409357 ], [ -103.432804673180627, 25.578715599888103 ], [ -103.432909948469174, 25.578782989112984 ], [ -103.433427834969251, 25.578053958210813 ] ] ] ] } }
]
}
